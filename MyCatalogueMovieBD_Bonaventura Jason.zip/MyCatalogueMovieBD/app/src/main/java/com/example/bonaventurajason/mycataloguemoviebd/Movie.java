package com.example.bonaventurajason.mycataloguemoviebd;

import android.database.Cursor;

import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.FavoriteMovieColumns.ADULT;
import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.FavoriteMovieColumns.DATE;
import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.FavoriteMovieColumns.MOVIE_ID;
import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.FavoriteMovieColumns.OVERVIEW;
import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.FavoriteMovieColumns.POPULARITY;
import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.FavoriteMovieColumns.TITLE;
import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.FavoriteMovieColumns.URL;
import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.FavoriteMovieColumns.VOTE_AVERAGE;
import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.FavoriteMovieColumns.VOTE_COUNT;
import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.getColumnInt;
import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.getColumnString;

public class Movie {
    public int id;
    public String title;
    public String overview;
    public String date;
    public String url;
    public String path;
    public int vote_count;
    public double vote_average;
    public double popularity;
    public boolean adult;

    public Movie() {
    }
    public Movie(Cursor cursor) {
        this.id = getColumnInt(cursor, MOVIE_ID);
        this.title = getColumnString(cursor, TITLE);
        this.overview = getColumnString(cursor, OVERVIEW);
        this.date = getColumnString(cursor, DATE);
        this.path = getColumnString(cursor, URL);
        this.url = "http://image.tmdb.org/t/p/w185/" + this.path;
        this.vote_count = getColumnInt(cursor, VOTE_COUNT);
        this.vote_average = getColumnInt(cursor, VOTE_AVERAGE);
        this.popularity = getColumnInt(cursor, POPULARITY);
        this.adult = getColumnInt(cursor, ADULT) > 0;
    }
    public Movie(int id, String title, String overview, String date, String url, int vote_count, double vote_average, double popularity, boolean adult) {
        this.id = id;
        this.title = title;
        this.overview = overview;
        this.date = date;
        this.path = url;
        this.url = "http://image.tmdb.org/t/p/w185/" + this.path;
        this.vote_count = vote_count;
        this.vote_average = vote_average;
        this.popularity = popularity;
        this.adult = adult;
    }

    public int getId() {
        return id;
    }
    public String getTitle() {
        return title;
    }
    public String getOverview() {
        return overview;
    }
    public String getDate() {
        return date;
    }
    public String getUrl() {
        return url;
    }
    public String getPath() {
        return path;
    }
    public int getVoteCount() {
        return vote_count;
    }
    public double getVoteAverage() {
        return vote_average;
    }
    public double getPopularity() {
        return popularity;
    }
    public boolean isAdult() {
        return adult;
    }

    @Override
    public String toString() {
        return "Movie{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", overview='" + overview + '\'' +
                ", date='" + date + '\'' +
                ", url='" + url + '\'' +
                ", vote_count=" + vote_count +
                ", vote_average=" + vote_average +
                ", popularity=" + popularity +
                ", adult=" + adult +
                '}';
    }
}
