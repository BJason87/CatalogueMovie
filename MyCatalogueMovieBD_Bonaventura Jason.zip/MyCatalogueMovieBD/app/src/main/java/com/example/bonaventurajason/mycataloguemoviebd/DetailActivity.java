package com.example.bonaventurajason.mycataloguemoviebd;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import butterknife.BindView;
import butterknife.ButterKnife;

import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.CONTENT_URI;
import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.FavoriteMovieColumns.ADULT;
import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.FavoriteMovieColumns.DATE;
import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.FavoriteMovieColumns.MOVIE_ID;
import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.FavoriteMovieColumns.OVERVIEW;
import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.FavoriteMovieColumns.POPULARITY;
import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.FavoriteMovieColumns.TITLE;
import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.FavoriteMovieColumns.URL;
import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.FavoriteMovieColumns.VOTE_AVERAGE;
import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.FavoriteMovieColumns.VOTE_COUNT;

public class DetailActivity extends AppCompatActivity {

    private static final String TAG = DetailActivity.class.getSimpleName();

    private MovieHelper movieHelper;
    @BindView(R.id.image_movie_extras) ImageView image_extras;
    @BindView(R.id.title_movie_extras) TextView title_extras;
    @BindView(R.id.date_movie_extras) TextView date_extras;
    @BindView(R.id.count_movie_extras) TextView count_extras;
    @BindView(R.id.average_movie_extras) TextView average_extras;
    @BindView(R.id.popularity_movie_extras) TextView popularity_extras;
    @BindView(R.id.adult_movie_extras) TextView adult_extras;
    @BindView(R.id.overview_movie_extras) TextView overview_extras;
    @BindView(R.id.favorite) ImageView image_favorite;

    Movie movie;
    private Cursor cursor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        ButterKnife.bind(this);

        movie = new Movie(getIntent().getExtras().getInt("id"), getIntent().getExtras().getString("title"),
                getIntent().getExtras().getString("overview"), getIntent().getExtras().getString("date"),
                getIntent().getExtras().getString("path"), getIntent().getExtras().getInt("vote_count"),
                getIntent().getExtras().getDouble("vote_average"), getIntent().getExtras().getDouble("popularity"),
                getIntent().getExtras().getBoolean("adult"));

        movieHelper = new MovieHelper(this);
        movieHelper.open();

        populateActivity();
    }

    @SuppressLint("SetTextI18n")
    public void populateActivity() {
        title_extras.setText(movie.getTitle());
        overview_extras.setText(movie.getOverview());
        date_extras.setText(getString(R.string.release_date)+" " + movie.getDate());
        Picasso.with(this).load(movie.getUrl())
                .into(image_extras);
        count_extras.setText(getString(R.string.vote_count)+" " +String.valueOf(movie.getVoteCount()));
        average_extras.setText(getString(R.string.vote_average)+" " +String.valueOf(movie.getVoteAverage()));
        popularity_extras.setText(getString(R.string.popularity)+" " +String.valueOf(movie.getPopularity()));
        if (movie.isAdult()) {
            adult_extras.setText(R.string.adult);
        } else {
            adult_extras.setText(R.string.nonAdult);
        }
        setStar();
    }
    public void addFavorite(View view) {
        Uri uri = Uri.parse(CONTENT_URI + "/" + movie.getId());
        cursor = getContentResolver().query(uri, null, null, null, null);
        if (cursor.getCount() > 0) {
            uri = Uri.parse(CONTENT_URI + "/" + movie.getId());
            getContentResolver().delete(uri, null, null);
            Toast.makeText(this, "Remove " + movie.getTitle() + " from favorite", Toast.LENGTH_SHORT).show();
            cursor.close();
        } else {
            uri = CONTENT_URI;
            ContentValues contentValues = new ContentValues();
            contentValues.put(MOVIE_ID, movie.getId());
            contentValues.put(TITLE, movie.getTitle());
            contentValues.put(OVERVIEW, movie.getOverview());
            contentValues.put(DATE, movie.getDate());
            Log.d(TAG, "addFavorite: " + movie.getPath());
            contentValues.put(URL, movie.getPath());
            contentValues.put(VOTE_COUNT, movie.getVoteCount());
            contentValues.put(VOTE_AVERAGE, movie.getVoteAverage());
            contentValues.put(POPULARITY, movie.getPopularity());
            contentValues.put(ADULT, movie.isAdult());
            getContentResolver().insert(uri, contentValues);
            Toast.makeText(this, "Add " + movie.getTitle() + " to favorite", Toast.LENGTH_SHORT).show();
        }
        setStar();
    }

    public void setStar() {
        Uri uri = Uri.parse(CONTENT_URI + "/" + movie.getId());
        cursor = getContentResolver().query(uri, null, null, null, null);
        if (cursor.getCount() > 0) {
            image_favorite.setImageResource(R.drawable.ic_star_black_24dp);
            cursor.close();
        }
        else image_favorite.setImageResource(R.drawable.ic_star_border_black_24dp);
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (movieHelper != null) movieHelper.close();
    }
}
