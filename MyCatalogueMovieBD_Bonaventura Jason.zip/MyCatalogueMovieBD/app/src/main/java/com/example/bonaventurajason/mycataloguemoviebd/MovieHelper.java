package com.example.bonaventurajason.mycataloguemoviebd;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.FavoriteMovieColumns.ADULT;
import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.FavoriteMovieColumns.DATE;
import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.FavoriteMovieColumns.MOVIE_ID;
import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.FavoriteMovieColumns.OVERVIEW;
import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.FavoriteMovieColumns.POPULARITY;
import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.FavoriteMovieColumns.TITLE;
import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.FavoriteMovieColumns.URL;
import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.FavoriteMovieColumns.VOTE_AVERAGE;
import static com.example.bonaventurajason.mycataloguemoviebd.DatabaseContract.FavoriteMovieColumns.VOTE_COUNT;

public class MovieHelper {
    private static String TABLE = DatabaseContract.TABLE_FAVORITE_MOVIE;
    private Context context;
    private DatabaseHelper dbHelper;
    private SQLiteDatabase db;

    public MovieHelper(Context context) {
        this.context = context;
    }

    public MovieHelper open() throws SQLException {
        dbHelper = new DatabaseHelper(context);
        db = dbHelper.getWritableDatabase();
        return this;
    }
    public void close() {
        dbHelper.close();
    }

    public ArrayList<Movie> selectAll() {
        ArrayList<Movie> movies = new ArrayList<>();
        Cursor cursor = db.query(TABLE, null, null, null, null,
                null, DatabaseContract.FavoriteMovieColumns._ID + " DESC", null);
        cursor.moveToFirst();
        Movie movie;
        if (cursor.getCount() > 0) {
            do {
                movie = new Movie(cursor.getInt(cursor.getColumnIndexOrThrow(MOVIE_ID)),
                        cursor.getString(cursor.getColumnIndexOrThrow(TITLE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(OVERVIEW)),
                        cursor.getString(cursor.getColumnIndexOrThrow(DATE)),
                        cursor.getString(cursor.getColumnIndexOrThrow(URL)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(VOTE_COUNT)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(VOTE_AVERAGE)),
                        cursor.getDouble(cursor.getColumnIndexOrThrow(POPULARITY)),
                        cursor.getInt(cursor.getColumnIndexOrThrow(ADULT)) > 0);
                movies.add(movie);
                cursor.moveToNext();
            }
            while (!cursor.isAfterLast());
        }
        cursor.close();
        return movies;
    }
    public Movie selectById(int id) {
        String selection = MOVIE_ID + " = ?";
        String[] selectionArgs = {String.valueOf(id)};
        Cursor cursor = db.query(TABLE, null, selection, selectionArgs, null,
                null, null, null);
        cursor.moveToFirst();
        Movie movie = null;
        //cursor
        if (cursor.getCount() > 0) {
            movie = new Movie(cursor.getInt(cursor.getColumnIndexOrThrow(MOVIE_ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(TITLE)),
                    cursor.getString(cursor.getColumnIndexOrThrow(OVERVIEW)),
                    cursor.getString(cursor.getColumnIndexOrThrow(DATE)),
                    cursor.getString(cursor.getColumnIndexOrThrow(URL)),
                    cursor.getInt(cursor.getColumnIndexOrThrow(VOTE_COUNT)),
                    cursor.getDouble(cursor.getColumnIndexOrThrow(VOTE_AVERAGE)),
                    cursor.getDouble(cursor.getColumnIndexOrThrow(POPULARITY)),
                    cursor.getInt(cursor.getColumnIndexOrThrow(ADULT)) > 0);
        }
        cursor.close();
        return movie;
    }
    public long insert(Movie movie){
        ContentValues initialValues =  new ContentValues();
        initialValues.put(MOVIE_ID, movie.getId());
        initialValues.put(TITLE, movie.getTitle());
        initialValues.put(OVERVIEW, movie.getOverview());
        initialValues.put(DATE, movie.getDate());
        initialValues.put(URL, movie.getPath());
        initialValues.put(VOTE_COUNT, movie.getVoteCount());
        initialValues.put(VOTE_AVERAGE, movie.getVoteAverage());
        initialValues.put(POPULARITY, movie.getPopularity());
        initialValues.put(ADULT, movie.isAdult());
        return db.insert(TABLE, null, initialValues);
    }
    public int update(Movie movie){
        ContentValues args = new ContentValues();
        args.put(MOVIE_ID, movie.getId());
        args.put(TITLE, movie.getTitle());
        args.put(OVERVIEW, movie.getOverview());
        args.put(DATE, movie.getDate());
        args.put(URL, movie.getUrl());
        args.put(VOTE_COUNT, movie.getVoteCount());
        args.put(VOTE_AVERAGE, movie.getVoteAverage());
        args.put(POPULARITY, movie.getPopularity());
        args.put(ADULT, movie.isAdult());
        return db.update(TABLE, args, MOVIE_ID + "= '" + movie.getId() + "'", null);
    }
    public int delete(int id){
        return db.delete(TABLE, MOVIE_ID + " = '"+id+"'", null);
    }

    public Cursor selectAllProvider() {
        return db.query(TABLE, null, null, null,
                null, null, DatabaseContract.FavoriteMovieColumns._ID + " DESC");
    }
    public Cursor selectByIdProvider(String id) {
        String selection = MOVIE_ID + " = ?";
        String[] selectionArgs = {id};
        return db.query(TABLE, null, selection, selectionArgs, null,
                null, null, null);
    }
    public long insertProvider(ContentValues contentValues) {
        return db.insert(TABLE, null, contentValues);
    }
    public int updateProvider(String id, ContentValues contentValues) {
        String selection = MOVIE_ID + " = ?";
        String[] selectionArgs = {id};
        return db.update(TABLE, contentValues, selection, selectionArgs);
    }
    public int deleteProvider(String id) {
        String selection = MOVIE_ID + " = ?";
        String[] selectionArgs = {id};
        return db.delete(TABLE, selection, selectionArgs);
    }
}
